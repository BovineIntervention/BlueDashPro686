# BlueDashPro
New, working, and rewritten version of [BlueDash](https://github.com/sykeben/BlueDash).   

**Documentation**  
All documentation will be in the [wiki](https://github.com/sykeben/BlueDashPro/wiki) (which may be outdated), please head there if needed.   

**Support**  
If something isn't working, or you want to suggest a feature, write an [issue](https://github.com/sykeben/BlueDashPro/issues).   
